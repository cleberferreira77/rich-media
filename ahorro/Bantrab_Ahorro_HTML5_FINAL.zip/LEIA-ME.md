# Bantrab Ahorro — HTML5 Rich Media

Dois anúncios independentes (`futuro` e `suenos`). Cada um tem versões Floating Object e 3D Cube em 300×250, 400×300, 600×400 e 1080×1920 px: 16 arquivos de entrega.

- Preview: `/p/bantrab-ahorro`
- Cartelas estáticas: `/ahorro/review.html`
- Fotos, assinatura, título e textos extraídos dos PSDs `SLIDE 10 str.psd` e `SLIDE 11_STR.psd`.
- O PSD `SLIDE 10.psd` é a versão quadrada da primeira história; não introduz uma terceira mensagem.
- Todos os assets estão locais em cada pasta de peça. Os ZIPs de entrega ficam em `packages/`.
- Destino: `https://experienciabantrab.com/ahorro/`, com suporte a `window.clickTag` e `window.clickTAG`.
- 3D Cube: as quatro faces alternam foto e mensagem com assinatura e CTA na face azul. Cada giro de 90° segue para a esquerda, sem telas vazias.
- Para regenerar após alterações em `src/`: `python3 ahorro/src/build.py`.

O arquivo `.crdownload` enviado pelo cliente estava incompleto e não foi usado.
